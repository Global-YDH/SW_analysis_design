import java.util.*;
/**
 *
 * 
 * @author (2018225134 ㅌㅐ, 2019315002 ㄱㅜ, 2019315028 ㅇㅠ, 2019603035 ㅎㅕㄴ) 
 * @version (ㄱㅗㅏㅈㅔ#3)
 */
public class Loan
{
    private Borrower borrower;
    private Book book;
    
    public Loan(Book book, Borrower borrower){
        this.book=book;
        this.borrower=borrower;
    }
    
    public void add(Loan loan){
        loan.add(loan);
    }
    
    public void remove(Loan loan){
        loan.remove(loan);
    }

    public void attachBook(Book book){
        this.book = book;
    }

    public void attachBorrower(Borrower borrower){
        this.borrower = borrower;
    }

    public void detachBook() {
        this.book = null;
    }

    public void detachBorrower() {
        this.borrower = null;
    }
}