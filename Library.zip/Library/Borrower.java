import java.util.*;
/**
 * Borrower
 * 
 * @author (2018225134 ㅌㅐ, 2019315002 ㄱㅜ, 2019315028 ㅇㅠ, 2019603035 ㅎㅕㄴ) 
 * @version (ㄱㅗㅏㅈㅔ#3)
 */
public class Borrower
{
    private String name; 
    
    private Loan loan;
    public Borrower(String name){
        this.name = name;
    }
    
    public static boolean contains(Borrower borrower){
        if(Borrower.contains(borrower) == true){
            return true;
        }
        else{
            return false;
        }
    } 
    
    public String getName(){
        return this.name;
    }
    
    public void add(Borrower borrower){
        borrower.add(borrower);
    }

    public void attachLoan(Loan loan){
        loan.attachBorrower(this); //대출 객체에 해당 이용자를 배당
    }    

    public void detachLoan(Loan loan){
        loan.detachBorrower();//대출 객체에서 해당 이용자를 배당 해제
        this.loan = null;
    }
}
