import java.util.*;
/**
 * 여기에 Borrower 클래스 설명을 작성하십시오.
 * 
 * @author (2018225134 ㅌㅐ, 2019315002 ㄱㅜ, 2019315028 ㅇㅠ, 2019603035 ㅎㅕㄴ) 
 * @version (ㄱㅗㅏㅈㅔ#3)
 */
public class Book extends TreeSet
{
    private String title;
    private String author;
    private int catalogueNumber;
    
    private Loan loan;
    public Book(String title, String author)
    {
        this.title = title;
        this.author = author;
    }
    
    public Book(String title, String author, int catalogueNumber)
    {
        this.title = title;
        this.author = author;
        this.catalogueNumber = catalogueNumber;
    }

    public boolean contains(Book book){
         if(this.contains(book) == true){
            return true;
        }
        else{
            return false;
        }
    }
    
    public String getTitle(){
        return this.title;
    }
    
    public String getAuthor(){
        return this.author;
    }

    public static boolean add(Book book){
        Book.add(book);
        return true;
    }

    public boolean checkLoan(){
        if(this.loan == null){
            return false;
        }
        else{
            return true;
        }
    }

    public void attachLoan(Loan loan){
        loan.attachBook(this);
        this.loan = loan;
    }
    
    public void detachLoan(Loan loan){
        loan.detachBook();
        this.loan = null;
    }
    
    public void setCatalogueNumber(int catalogueNumber){
        this.catalogueNumber = catalogueNumber;
    }
}
